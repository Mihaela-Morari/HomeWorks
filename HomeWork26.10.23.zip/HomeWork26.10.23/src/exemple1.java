import java.time.LocalDate;
import java.time.Year;
import java.util.Arrays;
public class exemple1 {
    public static void main(String[] args) {
        LocalDate[] dates = {
                LocalDate.of(1997, 1, 15),
                LocalDate.of(1855, 2, 23),
                LocalDate.of(2020, 12, 12),
                LocalDate.of(1999, 11, 15),
                LocalDate.of(1998, 2, 13),
                LocalDate.of(1990, 6, 10),
                LocalDate.of(1996, 11, 1),
                LocalDate.of(1995, 10, 16),
        };
        System.out.println("The dates:");
        System.out.println(Arrays.toString(dates));
        System.out.println();
        yearSort(dates);
        System.out.println("Sorting by year:");
        System.out.println(Arrays.toString(dates));
        System.out.println();
        daySort(dates);
        System.out.println("Sorting by day of month:");
        System.out.println(Arrays.toString(dates));
    }
    private static void yearSort(LocalDate[] date) {
        int n = date.length;
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (date[j].getYear()>date[j+1].getYear()){
                    LocalDate temp = date[j];
                    date[j]=date[j+1];
                    date[j+1] =temp;
                }
            }
        }
    }
    private static void daySort(LocalDate[] date) {
        int n = date.length;
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (date[j].getDayOfMonth()>date[j+1].getDayOfMonth()){
                    LocalDate temp = date[j];
                    date[j]=date[j+1];
                    date[j+1] =temp;
                }
            }
        }
    }
}
/*№1. Сортировка
1 Создайте массив из 8 элементов. В массиве должны храниться
даты (класс LocalDate). Чтобы создать элемент LocalDate используйте
 метод LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
Выведите массив в консоль.
2 Напишите метод, который отсортирует массив дат по году. Выведите массив
 в консоль.
3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите
 массив в консоль.
Сортировку можно выполнить по любому из изученных алгоритмов.
Пример создания массива с датами:
*/