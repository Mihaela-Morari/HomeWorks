import java.time.LocalDate;
import java.util.Arrays;

public class exemple2 {
    public static void main(String[] args) {
        char[][] letters = new char[3][11];
        char letter = 'А';
        for (int i = 0; i < letters.length; i++) {
            for (int j = 0; j < letters[i].length; j++) {
                letters[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж') {
                    if (j == letters[i].length-1) {
                        i++;
                        j = 0;
                    } else {
                        j++;
                    }
                    letters[i][j] = 'Ё';
                }
            }
        }
        System.out.println(Arrays.deepToString(letters));
    }
}
/*№2. Двумерные массивы ЖКУЦЙЙЪХЙЦУКЕНГШЩЗ/ЭЖДЛОРПАВЫФФФФФ/ЯЧСМИТЬБЮ,/Ё
Создайте двумерный массив и заполните его заглавными
буквами русского алфавита. Буква Ё должна быть на своём месте.*/