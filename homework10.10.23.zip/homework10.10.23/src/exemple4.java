import java.util.Scanner;

public class exemple4 {
    public static void main(String[] args) {
        System.out.println("Bводитe  целое число");
        Scanner scr = new Scanner(System.in);
        int num = scr.nextInt();
        int result = num>>1;
        System.out.println("Результат деление на 2 = " + result);

        
        /*4 Пользователь вводит целое число. Напишите программу, которая делит
        это число на 2 и выводит результат. Остаток деления можно
       отбросить. Операторы деления /, умножения * и остатка от деления %
        применять нельзя.
        */

    }
}