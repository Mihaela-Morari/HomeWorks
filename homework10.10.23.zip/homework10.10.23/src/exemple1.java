import java.util.Scanner;

public class exemple1 {
    public static void main(String[] args) {
        System.out.println("Введите значение в км");
        Scanner scr = new Scanner(System.in);
        double km = scr.nextDouble();
        double mi = km * 0.621371192;
        double ft = km * 3280.8;
        double ar = km * 1406.07424071991;
        System.out.println(mi + " мили");
        System.out.println(ft + " фут");
        System.out.println(ar + " аршин");


       /* 1 Дана длина в метрах. Напишите программу, которая переводит
       указанное значение в км, мили, футы и аршины. Выведите начальное
       и конвертированные значения на экран.
        */

    }
}