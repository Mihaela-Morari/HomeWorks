import java.util.Scanner;

public class exemple2 {
    public static void main(String[] args) {
        System.out.println(" Вводите суммарную стоимость покупок:");
        Scanner scr = new Scanner(System.in);
        double sum1 = scr.nextDouble();
        System.out.println(" Вводите сумму денег, которую дал покупатель:");
        double sum2 = scr.nextDouble();
        int rest = (int) (sum2-sum1);
        int coin = (int) (sum2*100-sum1*100-rest*100);
        System.out.printf("Сумма сдачи: %d рублей и %s копеек ",rest,coin);

        /*2 Пользователь-продавец вводит суммарную стоимость покупок и
        сумму денег, которую дал покупатель. Выведите сумму сдачи в виде
        “X рублей и Y копеек”.
         */
    }
}