import java.util.Arrays;

public class exemple4 {
    public static void main(String[] args) {
        String[] exemple = new String[]{ "Hello!", "Hi!", "Hello world!", "Today is a beautiful day.", "It's a Friday"};
        System.out.println(Arrays.toString(exemple));

        int maxLength = Integer.MIN_VALUE;
        int minLength = Integer.MAX_VALUE;
        String longest = " ";
        String smallest = " ";
        for (int i = 0; i < exemple.length; i++) {
            if (exemple[i].length() > maxLength) {
                maxLength = exemple[i].length();
                longest = exemple[i];
            }
        }
        for (int i = 0; i < exemple.length; i++) {
            if (exemple[i].length() < minLength) {
                minLength = exemple[i].length();
                smallest = exemple[i];
            }
        }
        System.out.println(longest);
        System.out.println(smallest);
    }
}

/*Задание 4.
Создайте массив из 5 строк. Используя метод length() строк,
найдите строку с наибольшей длиной и строк с наименьшей длиной.
Выведите массив и полученный строки в консоль.

*/