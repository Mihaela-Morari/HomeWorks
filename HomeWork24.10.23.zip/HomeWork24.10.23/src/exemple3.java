import java.util.Arrays;
import java.util.Random;

import static java.util.Arrays.*;

public class exemple3 {
    public static void main(String[] args) {
        int[] numbers = new int[8];
        Random rn = new Random();
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = rn.nextInt(1, 50);
        }
        System.out.println(Arrays.toString(numbers));

        int[] n = num(numbers);
        System.out.println(Arrays.toString(n));
        Arrays.sort(n);
        System.out.println(Arrays.toString(n));
    }

    private static int[] num(int[] numbers2) {
        for (int i = 0; i < numbers2.length; i++) {
            if (0 != numbers2[i] % 2) {
                numbers2[i] = 0;
            }
        }
        return numbers2;
    }
}

/*Задание 3.
Создайте массив из 8 случайных целых чисел из интервала [1;50]
Выведите массив в консоль в строку.
Замените каждый элемент с нечетным индексом на ноль.
Снова выведете массив в консоль в отдельной строке.
Отсортируйте массив по возрастанию.
Снова выведете массив в консоль в отдельной строке.

*/