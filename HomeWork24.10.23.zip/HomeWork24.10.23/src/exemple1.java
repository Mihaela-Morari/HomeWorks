public class exemple1 {
    public static void main(String[] args) {
        System.out.println(x(2,3));
        System.out.println(x(5,3,6));
        System.out.println(x(5,6,2,3));
    }
    private  static int x(int num1 , int num2 ){
        int result;
        result = num1 * num2 ;
        return  result;
    }
    private  static int x(int num1, int num2, int num3 ){
        int result = 0;
        result = x(num1,num2) * num3 ;
        return  result;
    }
    private  static int x(int num1, int num2,int num3, int num4 ){
        int result = 0;
        result = x(num1,num2,num3) * num4;
        return  result;
    }
}
/* Задание 1.
Сделайте перегруженные методы для перемножения 2-х,
3-х и 4-х чисел. В методе умножения 3-х чисел используйте
вызов метода для 2-х чисел. В методе умножения 4-х чисел –
 вызов метода для 3-х чисел.
*/