import java.util.Scanner;

public class exemple2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a positive number:");
        int num = factorial(sc.nextInt());
        System.out.println("The factorial is: " + num);
    }

    private static int factorial(int n) {
        int result = 1;
        if (n < 0) {
            throw new RuntimeException("The number must be positive!");
        }
        if (n == 0) {
            return result;
        } else {
            for (int i = 1; i <= n; i++) {
                result = result * i;
            }
            return result;
        }
    }
}
/*Задание 2.
Используя рекурсию, написать метод вычисления
 факториала числа n (n!), вводимого с клавиатуры.*/