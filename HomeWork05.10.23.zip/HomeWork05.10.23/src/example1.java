import java.util.Random;

public class example1 {
    public static void main(String[] args) {
        Random b = new Random();
        byte by = (byte) b.nextInt(-128,127);
        System.out.println(by);

        Random s = new Random();
        short sh = (short) s.nextInt(-32768,32767);
        System.out.println(sh);

        Random i = new Random();
        int in = i.nextInt();
        System.out.println(in);

        Random l = new Random();
        long lo = l.nextLong();
        System.out.println(lo);

        Random f = new Random();
        float fl = f.nextFloat();
        System.out.println(fl);

        Random d = new Random();
        double dou = d.nextDouble();
        System.out.println(dou);

        Random c = new Random();
        char ch = (char) c.nextInt('a','z');
        System.out.println(ch);

        Random boo = new Random();
        boolean bool = boo.nextBoolean();
        System.out.println(bool);

        Random str = new Random();
        int a = str.nextInt();
        String st = a + "";
        System.out.println(st);
        String z = String.valueOf((char)str.nextInt('A','Z'+1)) + (char)str.nextInt('A','Z'+1);
        System.out.println(z);




   /*Задание 1
1 Напишите программу, в которой объявите переменные всех примитивных типов.
Значение для каждой переменной сгенерируйте с помощью класса Random. При необходимости
 используйте приведение типов. Полученные значения выведите в консоль.
2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
 При необходимости используйте метод String.valueOf(). Ограничений на длину строки и
 содержимое нет. Полученное значение выведите в консоль. */
    }
}