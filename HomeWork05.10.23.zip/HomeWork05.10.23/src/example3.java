import java.util.Scanner;

public class example3 {
    public static void main(String[] args) {

        System.out.println("Enter the first integer: ");
        Scanner scn1 = new Scanner(System.in);
        int num1 = scn1.nextInt();
        System.out.println("Enter the second integer: ");
        Scanner scn2 = new Scanner(System.in);
        int num2 = scn2.nextInt();
        System.out.printf("The %d added to the %d = %d ",num1,num2, num1+num2);
        System.out.printf("The %d minus the %d = %d ",num1,num2, num1-num2);
        System.out.printf("The %d multiplied by the %d = %d ",num1,num2, num1*num2);
        System.out.printf("The %d devided by the %d = %s ",num1,num2, num1*1.0/num2);


   /* Задание 3
Напишите программу, которая получает от пользователя два целых числа и затем вычисляет
 сумму (сложение), разницу (вычитание), произведение (умножение) и частное (деление)
 введённых чисел. Результат вычислений выведите в консоль. */
    }
}