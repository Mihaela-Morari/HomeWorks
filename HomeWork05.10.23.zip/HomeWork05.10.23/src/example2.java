import java.util.Scanner;

public class example2 {
    public static void main(String[] args) {
        System.out.println("Enter your name: ");
        Scanner name = new Scanner(System.in);
        String n = name.nextLine();
        System.out.println("Enter your age: ");
        Scanner age = new Scanner(System.in);
        int a = age.nextInt();
        System.out.println("Enter your weight:");
        Scanner weight = new Scanner(System.in);
        double w = weight.nextDouble();
        System.out.printf("Dear %s! At yours %d, You are as dear to us as a %s kilogram of gold.",n,a,w );

   /*Задание 2
   Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
 Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои
 [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.». В сообщении [Имя],
 [Возраст] и [Вес] должны принять введённые значения. */
    }
}