import aniversary.AniversaryWedding;

import java.util.Scanner;

public class exemple1 {
    public static void main(String[] args) {
        System.out.println("Enter how many years have you been married (Choose between: 1,2,3,4,5,10,20,30,40,50,60): ");
        Scanner sc = new Scanner(System.in);
        int year = sc.nextInt();
        AniversaryWedding nameAniversary = switch (year) {
            case 1 -> AniversaryWedding.PAPER_ANIVERSARY;
            case 2 -> AniversaryWedding.COTTON_ANIVERSARY;
            case 3 -> AniversaryWedding.LEATHER_ANIVERSARY;
            case 4 -> AniversaryWedding.SILK_ANIVVERSARY;
            case 5 -> AniversaryWedding.WOOD_ANIVERSARY;
            case 10 -> AniversaryWedding.ALUMINUM_ANIVERSARY;
            case 20 -> AniversaryWedding.PORCELAIN_ANIVERSARY;
            case 30 -> AniversaryWedding.PEARL_ANIVERSARY;
            case 40 -> AniversaryWedding.RUBY_ANIVERSARY;
            case 50 -> AniversaryWedding.GOLD_ANIVERSARY;
            case 60 -> AniversaryWedding.DIAMOND_ANIVERSARY;
            default -> throw new RuntimeException("Incorrect number.");
        };
        System.out.println(nameAniversary);

/*Задание 1.
Пользователь вводит, сколько лет он состоит в браке.
Программа должна вывести, какая годовщина свадьбы будет
у пользователя следующей (бумажная, ситцевая, чугунная,
серебряная и.д.). Не обязательно указывать все годовщины,
 достаточно 10-15. Узнать про годовщины можно, например,
  здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
*/    }
}