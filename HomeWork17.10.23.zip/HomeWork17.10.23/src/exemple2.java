import game.Game;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class exemple2 {
    public static void main(String[] args) {
        System.out.println("Choose between stone, scissors and paper:" + Arrays.toString(Game.values()));
        Scanner sc = new Scanner(System.in);
        String user = sc.nextLine();
        Game userChoise = Game.valueOf(user.toUpperCase(Locale.ROOT));
        Random rn = new Random();
        int comp = rn.nextInt(Game.values().length);
        Game compChoise = Game.values()[comp];
        System.out.println("The computer choosed:");
        System.out.println(compChoise);

        String result = switch (userChoise) {
            case STONE -> switch (compChoise) {
                case STONE -> "Game draw";
                case SCISSORS -> "The Stone win! Congratulations to the user! ";
                default -> "The Paper win! Sorry!";
            };
            case SCISSORS -> switch (compChoise) {
                case STONE -> "The Stone win! Sorry!";
                case SCISSORS -> "Game draw";
                default -> "The Scissors win! Congratulations to the user!";
            };
            case PAPER -> switch (compChoise) {
                case STONE -> "The Paper win! Congratulations to the user!";
                case SCISSORS -> "The Scissors! Sorry!" ;
                default -> "Game draw";
            };
        };
        System.out.println(result);

/*Задание 2.
Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
 свой выбор (в виде строки или числа). Программа случайным образом делает
  свой выбор и выводит на экран. Далее программа показывает, кто победитель
  – пользователь или программа.*/
    }
}
