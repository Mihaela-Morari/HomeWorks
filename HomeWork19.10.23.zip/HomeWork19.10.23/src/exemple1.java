import java.util.Random;

public class exemple1 {
    public static void main(String[] args) {
        int goal = 10000;
        int actualSum = 0;
        while (actualSum <= goal) {
            Random rn = new Random();
            int banknote = rn.nextInt(0, 4);
            int rnBanknote = switch (banknote) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                default -> 500;
            };
            actualSum = actualSum + rnBanknote;
        }
        System.out.println("Stop!We have "+actualSum + ". Let's drink for my health at the best bar in town!");
    }
}
/*Задание 1
Напиши программу, которая моделирует ситуацию.
Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
Каждый друг случайным образом может подарить тебе одну купюру номиналом 50,
 100, 200 или 500 долларов. Твоя цель - новенький игровой компьютер, который
 стоит 10 000 долларов.
Как только друзья подарят тебе нужную сумму (или даже чуть больше),
останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
*/