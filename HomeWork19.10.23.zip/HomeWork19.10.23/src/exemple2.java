import java.util.Scanner;

public class exemple2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String st = "";
        do {System.out.println("Enter the number one: ");
            int num1 = sc.nextInt();
            System.out.println("Enter the number two: ");
            int num2 = sc.nextInt();
            int sum = 0;
            int min = Math.min(num1,num2);
            int max = Math.max(num1,num2);
            for (int i = min; i <=max; i++) {
                if (i%2!=0 ){
                    sum +=i;
                }
            }
            System.out.println(sum);
            System.out.println("Do you want to try again or quit? For Quit enter 'Quit'.");
            st =new Scanner(System.in).nextLine();
        } while (!"quit".equalsIgnoreCase(st));

    }
}
/*Задание 2
Используйте for для вычисления суммы.
Используйте do-while для организации повторения программы.

Необходимо суммировать все нечётные целые числа в диапазоне,
введённом пользователем. Программу повторять, пока пользователь не введёт «quit».

*/