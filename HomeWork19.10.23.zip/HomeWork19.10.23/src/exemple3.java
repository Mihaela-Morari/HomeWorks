import week.DayOfWeek;

import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class exemple3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose a day of week and I will show you the rest of the days!" + Arrays.toString(DayOfWeek.values()));
        String user = sc.nextLine();
        System.out.println("The rest of the days:");
        DayOfWeek daysUser = DayOfWeek.valueOf(user.toUpperCase(Locale.ROOT));
        for (DayOfWeek d : DayOfWeek.values()) {
            if(d!=daysUser){
                System.out.println(d);
            }
            

        }
    }
}


/*Задание 3
Используйте foreach.
Дан Enum дней недели. Пользователь вводит имя текущего дня
 в консоль. Программа должна вывести все дни недели, кроме данного.*/