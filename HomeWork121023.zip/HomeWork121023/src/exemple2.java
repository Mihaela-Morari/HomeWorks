import java.util.Random;
import java.util.Scanner;

public class exemple2 {
    public static void main(String[] args) {
        Random rnd = new Random();
        int num1 = rnd.nextInt(0,10);
        int num2 = rnd.nextInt(1,10);
        System.out.println("первоe числo " + num1);
        System.out.println("второе числo " + num2);
        System.out.println("результат умножения первого числа на второе?");
        Scanner sc = new Scanner(System.in);
        int result1 = sc.nextInt();

        if (num1*num2==result1) {
            System.out.println("правильно!");
        } else {
            System.out.println("неправильно!");
            System.out.println("правильный ответ: " + (num1*num2));
        }


        /*№2
Необходимо написать программу, которая проверяет пользователя на
знание таблицы умножения. Программа генерирует два целых однозначных числа.
 Программа задаёт вопрос: результат умножения первого числа на второе?
  Пользователь должен ввести ответ и увидеть на экране правильно
 он ответил или нет. Если пользователь ответил неправильно, то программа
  должна показать правильный ответ.
*/
    }
}