public class exemple2 {
    public static void main(String[] args) {
        String st = new String("I study Basic Java");
        string(st);
        System.out.println(st.charAt(st.length()-1));
        System.out.println(st.contains("Java"));
        System.out.println(st.replace('a','o'));
        System.out.println(st.toUpperCase());
        System.out.println(st.toLowerCase());
        System.out.println(st.substring(st.trim().lastIndexOf(" ")+1));
    }
    private static String string(String str){
        str = str.intern();
        return str;
    }
}
/*Задание 2. Создайте строку через new - I study Basic Java!
Напишите метод, который принимает в качестве параметра строку,
передайте в этот метод созданную строку.
Распечатать последний символ строки. Используем метод String.charAt().
Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
Заменить все символы “а” на “о”.
Преобразуйте строку к верхнему регистру.
Преобразуйте строку к нижнему регистру.
Вырезать строку Java c помощью метода String.substring().
*/