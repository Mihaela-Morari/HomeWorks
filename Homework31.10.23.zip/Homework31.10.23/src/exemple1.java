import java.util.Scanner;

public class exemple1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first word with an even number of characters:");
        String word1 = control(sc.nextLine());
        System.out.println("Enter the second word with an even number of characters:");
        String word2 = control(sc.nextLine());
        System.out.println(word1.substring(0,word1.length()/2) + word2.substring(word2.length()/2));
    }
    private static String control(String word){
        int sum = word.length();
        if (sum%2!=0){
            throw new RuntimeException("Odd character number!");
        }else return word;
    }
}
/*Задание 1. Введите 2 слова, воспользуйтесь сканером,
 состоящие из четного количества букв (проверьте количество букв в слове).
Нужно получить слово, состоящее из первой половины первого слова и второй
половины второго слова. распечатать на консоль.
Например: ввод - mama, papa. Вывод – mapa*/