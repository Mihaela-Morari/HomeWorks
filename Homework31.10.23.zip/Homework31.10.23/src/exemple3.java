public class exemple3 {
    public static void main(String[] args) {
        StringBuilder st = new StringBuilder("AAAABBBCCCDDEGHHHIKL");
        System.out.println(count(st.toString()));

    }
    private static StringBuilder count(String string){
        StringBuilder result = new StringBuilder();
        char prevLetter = string.charAt(0);
        int length = 0;
        for (int i = 0; i < string.length() ; i++) {
            char currentLetter = string.charAt(i);
            if (prevLetter == currentLetter){
                length++;
            }else {
                result.append(prevLetter);
                result.append(length ==1?"":length);
                length = 1;
                prevLetter=currentLetter;
            }
        }
        result.append(prevLetter);
        result.append(length ==1?"":length);
        return result;
    }
}
/*Задание 3. Задание из собеседования Яндекс:
дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов
латинского алфавита. Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
 т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.*/